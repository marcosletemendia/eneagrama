<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class preguntas_largo extends Model
{
   public $table="preguntas_largo";
   //public $primaryKey = "id";
   public $timestamps = false;
  public $guarded=[];

  //public function test(){
   // return $this->hasMany('App\test','pregunta_id');
  //
}
