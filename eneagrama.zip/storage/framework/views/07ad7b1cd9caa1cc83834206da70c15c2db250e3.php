
<?php $__env->startSection('titulo'); ?>
   Test
<?php $__env->stopSection(); ?>

<?php $__env->startSection('principal'); ?>

   <div class="central">
      <h2>Test</h2>
      <div class="warning">


      <p>Esta es la version abreviada del Test, si no esta seguro del resultado, le sugerimos hacer el <a href="/fulltest">TEST COMPLETO</a></p>
      </div>      <img src="/storage/barraProgreso6.png" alt="">
      <form class="form" action="/pag8t" method="post">
         <?php echo e(csrf_field()); ?>

         <?php $__currentLoopData = $req->request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $re): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" name='pregunta<?php echo e($re); ?>' value=<?php echo e($re); ?>>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="contenedor_pregunta">
             <div class="input">
               <input type="checkbox" name="pregunta<?php echo e($pregunta->id); ?>" value=<?php echo e($pregunta->id); ?>>
             </div>
             <div class="chek">
              <label for="pregunta<?php echo e($pregunta->id); ?>"> <?php echo e($pregunta->id .') '. $pregunta->pregunta); ?></label>
             </div>
           </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <button type="submit" name="button">Siguiente</button>
      </form>
   </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marcelo/git/eneagramas/resources/views//test/pag7t.blade.php ENDPATH**/ ?>