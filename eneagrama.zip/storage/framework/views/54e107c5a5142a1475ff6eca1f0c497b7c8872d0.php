<?php $__env->startSection('principal'); ?>
<div class="central">
  <h2>Descargue el Libro Aqui</h2>
  <div class="descarga">


  <iframe src="https://docs.google.com/viewer?url=localhost:8000/storage/eneagramasinteriorespdfinteractivo(1).pdf&embedded=true" width="600" height="780" style="border: none;"></iframe>
  <a href="/storage/eneagramasinteriorespdfinteractivo(1).pdf" download="Eneagramas">
  Descargar Archivo
  </a>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marcelo/git/eneagramas/resources/views//succes.blade.php ENDPATH**/ ?>