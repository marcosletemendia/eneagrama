
<?php $__env->startSection('titulo'); ?>
   Recibir
<?php $__env->stopSection(); ?>

<?php $__env->startSection('principal'); ?>
   <div class="central">
      <h2>QUÉ REGALO RECIBE DE OTRAS TIPOLOGÍAS</h2>
      <p>Al reconocer que el encuentro consigo mismo se dará de la mano de los otros,
         el DOS puede tomar el regalo de sus alas UNO y TRES que le dicen, organizate,
         priorizate; de sus brazos OCHO y CUATRO que lo estimulan a poner límites y
         mirarse, de sus eneatipos consonantes SEIS y SIETE que le proponen pedir y
         relajarse; y, finalmente, de sus puntos ciegos CINCO y NUEVE que lo invitan a
         diferenciar y parar en el proceso de encuentro consigo mismo.
      </p>
      <ol>
         <li><a href="recibir1">El UNO recibe</a></li>
         <li><a href="recibir2">El DOS recibe</a></li>
         <li><a href="recibir3">El TRES recibe</a></li>
         <li><a href="recibir4">El CUATRO recibe</a></li>
         <li><a href="recibir5">El CINCO recibe</a></li>
         <li><a href="recibir6">El SEIS recibe</a></li>
         <li><a href="recibir7">El SIETE recibe</a></li>
         <li><a href="recibir8">El OCHO recibe</a></li>
         <li><a href="recibir9">El NUEVE recibe</a></li>
      </ol>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marcelo/git/eneagramas/resources/views//recibir/recibir2.blade.php ENDPATH**/ ?>