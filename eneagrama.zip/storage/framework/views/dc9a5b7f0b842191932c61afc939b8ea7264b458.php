<?php $__env->startSection('principal'); ?>
  <div class="central">

    <?php if(Auth::user()->collection_status=='approved'): ?>
      <h2>Descargue el Libro Aqui</h2>
      <div class="descarga">

      <a href="/storage/eneagramasinteriorespdfinteractivo(1).pdf" download="Eneagramas">
      Descargar Ebook
      </a>
      </div>

  <?php elseif( Auth::user()->collection_status=='error'): ?>
      <h2>Elija el Metodo de Pago</h2>
      <div class="pago">
        <a href="/checkout/preferences"><img src="/storage/mercadopago.jpg" alt=""></a>
        <a href="/paypal"><img src="/storage/paypal.jpg" alt=""></a>
      </div>

  <?php else: ?>
    <h2>Su compra esta aguardando confirmacion</h2>

<?php endif; ?>




</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marcelo/git/eneagramas/resources/views//download.blade.php ENDPATH**/ ?>