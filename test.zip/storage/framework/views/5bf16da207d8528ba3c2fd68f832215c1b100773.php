<?php $__env->startSection('titulo'); ?>
  Test de Personalidad
<?php $__env->stopSection(); ?>

<?php $__env->startSection('principal'); ?>


  <div class="central">
    <h2>Test de Personalidad</h2>
    <div class="warning">


    <p>Esta es la version abreviada del Test, si no esta seguro del resultado, le sugerimos hacer el <a href="/fulltest">TEST COMPLETO</a></p>
    </div>
    <form class="form" action="/devolucion" method="POST">
       <?php echo e(csrf_field()); ?>

      <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="">
        <div class="check">
          <input type="checkbox" name="pregunta<?php echo e($pregunta->id); ?>" value="<?php echo e($pregunta->id); ?>">
        </div>
        <div class="check">
          <label for="pregunta <?php echo e($pregunta->id); ?>"><?php echo e($pregunta->id . ' '. $pregunta->pregunta); ?></label>
          <br>
        </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <button type="submit" name="button">Averigualo</button>
    </form>




  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marcelo/git/eneagramas/resources/views//prueba.blade.php ENDPATH**/ ?>