<?php $__env->startSection('titulo'); ?>
   Comprar Libro
<?php $__env->stopSection(); ?>

<?php $__env->startSection('principal'); ?>
  <div class="central">
    <h2>Elija el Metodo de Pago</h2>
    <div class="pago">
      <a href="/checkout/preferences"><img src="/storage/mercadopago.jpg" alt=""></a>
      <a href="/paypal"><img src="/storage/paypal.jpg" alt=""></a>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marcelo/git/eneagramas/resources/views/compra.blade.php ENDPATH**/ ?>